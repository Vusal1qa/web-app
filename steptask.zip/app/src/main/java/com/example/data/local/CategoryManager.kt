package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class CategoryManager(context: Context) {
    private val prefs: SharedPreferences =
        (context.applicationContext ?: context).getSharedPreferences("task_category_prefs", Context.MODE_PRIVATE)

    private val defaultCategories = listOf("Work", "Tech", "Life & Home", "Study", "Writing", "Health")

    private val _categories: MutableStateFlow<List<String>>

    init {
        val initialList = loadInitialCategories()
        _categories = MutableStateFlow(initialList)
    }

    val categories: StateFlow<List<String>> get() = _categories.asStateFlow()

    private fun loadInitialCategories(): List<String> {
        val hasKey = prefs.contains(KEY_CATEGORIES)
        if (!hasKey) {
            // First run: save defaults
            val distinctList = defaultCategories.distinct()
            prefs.edit().putString(KEY_CATEGORIES, distinctList.joinToString(DELIMITER)).apply()
            return distinctList
        }
        val saved = prefs.getString(KEY_CATEGORIES, "") ?: ""
        return if (saved.isBlank()) {
            emptyList()
        } else {
            saved.split(DELIMITER).map { it.trim() }.filter { it.isNotEmpty() }
        }
    }

    fun setCategories(list: List<String>) {
        saveCategories(list)
    }

    private fun saveCategories(list: List<String>) {
        val distinctList = list.distinct()
        _categories.value = distinctList
        prefs.edit().putString(KEY_CATEGORIES, distinctList.joinToString(DELIMITER)).apply()
    }

    fun addCategory(name: String): Boolean {
        val trimmed = name.trim()
        if (trimmed.isEmpty() || trimmed.equals("All", ignoreCase = true)) {
            return false
        }
        val current = _categories.value.toMutableList()
        if (current.any { it.equals(trimmed, ignoreCase = true) }) {
            return false
        }
        current.add(trimmed)
        saveCategories(current)
        return true
    }

    fun deleteCategory(name: String): Boolean {
        val trimmed = name.trim()
        val current = _categories.value.toMutableList()
        val removed = current.removeAll { it.equals(trimmed, ignoreCase = true) }
        if (removed) {
            saveCategories(current)
            return true
        }
        return false
    }

    fun renameCategory(oldName: String, newName: String): Boolean {
        val oldTrimmed = oldName.trim()
        val newTrimmed = newName.trim()
        if (newTrimmed.isEmpty() || newTrimmed.equals("All", ignoreCase = true)) {
            return false
        }
        val current = _categories.value.toMutableList()
        val index = current.indexOfFirst { it.equals(oldTrimmed, ignoreCase = true) }
        if (index == -1) return false
        
        // If changing to another existing category name (other than self)
        if (current.any { it.equals(newTrimmed, ignoreCase = true) && !it.equals(oldTrimmed, ignoreCase = true) }) {
            return false
        }

        current[index] = newTrimmed
        saveCategories(current)
        return true
    }

    companion object {
        private const val KEY_CATEGORIES = "key_user_categories"
        private const val DELIMITER = "||"

        @Volatile
        private var INSTANCE: CategoryManager? = null

        fun getInstance(context: Context): CategoryManager {
            return INSTANCE ?: synchronized(this) {
                val appContext = context.applicationContext ?: context
                val instance = CategoryManager(appContext)
                INSTANCE = instance
                instance
            }
        }
    }
}

